from django.apps import AppConfig

class TracktimeConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "tracktime"
    verbose_name = "Track Time"
