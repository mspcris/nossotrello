// boards/static/boards/modal/modal.drag.js
// RESPONSABILIDADE ÚNICA:
// - Diferenciar CLICK de DRAG
// - Abrir modal SOMENTE se for click
// - NUNCA interferir no SortableJS

(function () {
  console.log("[modal.drag] loaded");

  const DRAG_THRESHOLD = 6;

  let startX = 0;
  let startY = 0;
  let moved = false;
  let activeCard = null;

  window.__isDraggingCard = false;

  function getCard(el) {
    return el && el.closest && el.closest(".card-item, li[data-card-id]");
  }

  // ============================
  // POINTER DOWN
  // ============================
  document.addEventListener(
    "pointerdown",
    function (ev) {
      const card = getCard(ev.target);
      if (!card) return;

      // ignora botões/links/controles internos e qualquer coisa HTMX
      if (ev.target.closest("button, a, input, textarea, select, [contenteditable='true'], [hx-get], [hx-post]")) {
        return;
      }

      startX = ev.clientX;
      startY = ev.clientY;
      moved = false;
      activeCard = card;
      window.__isDraggingCard = false;
    },
    true
  );

  // ============================
  // POINTER MOVE
  // ============================
  document.addEventListener(
    "pointermove",
    function (ev) {
      if (!activeCard) return;

      const dx = Math.abs(ev.clientX - startX);
      const dy = Math.abs(ev.clientY - startY);

      if (dx > DRAG_THRESHOLD || dy > DRAG_THRESHOLD) {
        moved = true;
        window.__isDraggingCard = true;
      }
    },
    true
  );

  // ============================
  // POINTER UP
  // ============================
  document.addEventListener(
    "pointerup",
    function (ev) {
      if (!activeCard) return;

      // ✅ se outro handler já tratou (ex.: click do modal.open.js), não faz nada aqui
      if (ev.defaultPrevented || ev.__modalHandled) {
        activeCard = null;
        moved = false;
        window.__isDraggingCard = false;
        return;
      }

      const card = activeCard;
      activeCard = null;

      // CLICK REAL → abre modal
      if (!moved) {
        const cardId = Number(card.dataset.cardId);
        if (cardId) {
          try {
            // se existir a facade correta, use ela
            if (window.Modal && typeof window.Modal.openCard === "function") {
              window.Modal.openCard(cardId, false);
              ev.__modalHandled = true;
            } else if (window.htmx) {
              // fallback mínimo
              window.htmx.ajax("GET", `/card/${cardId}/modal/`, {
                target: "#modal-body",
                swap: "innerHTML",
              });

              // tenta abrir se o core existir
              if (window.Modal && typeof window.Modal.open === "function") {
                window.Modal.open();
              }

              ev.__modalHandled = true;
            }
          } catch (_e) {
            // silencioso: não derruba UX do board
          }
        }
      }

      moved = false;

      setTimeout(() => {
        window.__isDraggingCard = false;
      }, 0);
    },
    true
  );
})();
 // END boards/static/boards/modal/modal.drag.js
