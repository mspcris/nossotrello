// boards/static/boards/modal/modal.open.js
// RESPONSABILIDADE:
// - Capturar clique em card (sem conflito com drag / botões internos)
// - Carregar conteúdo via HTMX para #modal-body
// - Abrir modal de forma GARANTIDA (não depender só de afterSwap)

(() => {
  console.log("[modal.open] loaded");

  if (!window.Modal) {
    console.error("[modal.open] modal.core.js não carregado (window.Modal ausente)");
    return;
  }

  // evita double-load (se já existir openCard, não redefine)
  if (typeof window.Modal.openCard === "function") return;

  function getModalBody() {
    return document.getElementById("modal-body");
  }

  function safeOpenModal() {
    if (typeof window.Modal.open === "function") {
      window.Modal.open();

      // reforço de acessibilidade/estado (não quebra se não existir)
      const modal = document.getElementById("modal");
      if (modal) modal.setAttribute("aria-hidden", "false");
    }
  }

  function loadCard(cardId, replaceUrl = false) {
    const id = Number(cardId);
    if (!id) return;

    // gate (se existir)
    if (typeof window.Modal.canOpen === "function" && !window.Modal.canOpen()) return;

    // precisa existir o target no DOM
    const target = getModalBody();
    if (!target) {
      console.error("[modal.open] #modal-body não existe no DOM");
      return;
    }

    // marca estado antes do request
    window.Modal.state.currentCardId = id;

    // URL helper (se existir)
    if (window.Modal.url && typeof window.Modal.url.set === "function") {
      window.Modal.url.set(id, { replace: !!replaceUrl });
    }

    // 🔑 ABRE AGORA (não depende de afterSwap)
    safeOpenModal();

    // faz o request HTMX
    const hx = window.htmx;
    if (!hx || typeof hx.ajax !== "function") {
      console.error("[modal.open] HTMX não carregado (window.htmx ausente).");
      return;
    }

    hx.ajax("GET", `/card/${id}/modal/`, {
      target: "#modal-body",
      swap: "innerHTML",
    });
  }

  // Clique no card (captura antes de outros handlers)
  document.addEventListener(
    "click",
    (ev) => {
      const card = ev.target.closest("li[data-card-id], .card-item[data-card-id]");
      if (!card) return;

      // ignora clique em controles internos
      if (ev.target.closest("button, a, input, textarea, select, [contenteditable='true'], [hx-get], [hx-post]")) {
        return;
      }

      // se tiver drag ativo, não abre
      if (window.__isDraggingCard) return;

      // gate (se existir)
      if (typeof window.Modal.canOpen === "function" && !window.Modal.canOpen()) return;

      // evita “duplo tratamento” (click + pointerup)
      if (ev.defaultPrevented || ev.__modalHandled) return;

      ev.preventDefault();
      ev.stopPropagation();
      ev.__modalHandled = true;

      const cardId = Number(card.dataset.cardId);
      loadCard(cardId, false);
    },
    true
  );

  // Reforço: quando HTMX swap terminar no modal-body, garante modal aberto
  document.addEventListener("htmx:afterSwap", (e) => {
    const target = e.detail?.target || e.target;
    if (!target || target.id !== "modal-body") return;

    safeOpenModal();
  });

  // Boot por URL (?card=)
  document.addEventListener("DOMContentLoaded", () => {
    if (window.Modal.url && typeof window.Modal.url.getCardIdFromUrl === "function") {
      const cardId = window.Modal.url.getCardIdFromUrl();
      if (cardId) loadCard(cardId, true);
    }
  });

  // API pública
  window.Modal.openCard = loadCard;
})();
 // END boards/static/boards/modal/modal.open.js
