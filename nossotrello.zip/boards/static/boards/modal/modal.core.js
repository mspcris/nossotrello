// boards/static/boards/modal/modal.core.js
(() => {
  "use strict";

  // ---------------------------------------------------------------------------
  // Robust bootstrap:
  // - Nunca aborta só porque window.Modal já existe (pode ter sido criado por outro script)
  // - Garante que open/close existam sempre
  // - Evita double-load usando flag interna (__coreLoaded)
  // ---------------------------------------------------------------------------

  const existing = window.Modal;

  // Normaliza para objeto
  const Modal =
    existing && typeof existing === "object" ? existing : {};

  // Se core já foi carregado, ainda assim garante open/close (hardening)
  if (Modal.__coreLoaded) {
    if (typeof Modal.open !== "function") {
      Modal.open = function open() {
        const modal = document.getElementById("modal");
        if (!modal) return;

        modal.classList.remove("hidden");
        modal.classList.add("modal-open");
        Modal.state.isOpen = true;
      };
    }

    if (typeof Modal.close !== "function") {
      Modal.close = function close() {
        const modal = document.getElementById("modal");
        const body = document.getElementById("modal-body");
        if (!modal) return;

        modal.classList.remove("modal-open");
        modal.classList.add("hidden");

        if (body) body.innerHTML = "";

        Modal.state.isOpen = false;
        Modal.state.currentCardId = null;
      };
    }

    window.Modal = Modal;
    return;
  }

  Modal.__coreLoaded = true;

  // Estado: preserva se já existir, cria se não existir
  Modal.state = (Modal.state && typeof Modal.state === "object")
    ? Modal.state
    : {};

  if (typeof Modal.state.currentCardId === "undefined") Modal.state.currentCardId = null;
  if (typeof Modal.state.isOpen === "undefined") Modal.state.isOpen = false;

  // ---------------------------------------------------------------------------
  // Open / Close: sempre disponíveis
  // ---------------------------------------------------------------------------

  Modal.open = function open() {
    const modal = document.getElementById("modal");
    if (!modal) return;

    modal.classList.remove("hidden");
    modal.classList.remove("modal-closing");
    modal.classList.add("modal-open");

    Modal.state.isOpen = true;
  };

  Modal.close = function close() {
    const modal = document.getElementById("modal");
    const body = document.getElementById("modal-body");

    if (!modal) return;

    modal.classList.remove("modal-open");
    modal.classList.add("hidden");

    if (body) body.innerHTML = "";

    Modal.state.isOpen = false;
    Modal.state.currentCardId = null;
  };

  // Exposição final (mantém referência estável)
  window.Modal = Modal;
})();
// END // boards/static/boards/modal/modal.core.js
