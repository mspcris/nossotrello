# boards/views.py
from .views import *  # reexporta tudo do package boards/views/
#END boards/views.py
